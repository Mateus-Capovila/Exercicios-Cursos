/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ultraemojicombat;

/**
 *
 * @author Gabriel
 */
public class UltraEmojiCombat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Lutador l[] = new Lutador[6];
                l[0] = new Lutador("Pretty Boy", "França", 26, 11, 2, 3, 1.96f, 91.3f);
                l[1] = new Lutador("Gritadeira", "Tamaran", 16, 14, 2, 3, 1.8f, 69.7f);
                l[2] = new Lutador("Stone", "USA", 19, 10, 0, 1, 2f, 105.7f);
                l[3] = new Lutador("Thrawn", "Chiss", 36, 7, 2, 2, 1.84f, 80.8f);
                l[4] = new Lutador("Spider", "USA", 15, 12, 0, 0, 1.75f, 65.2f);
                l[5] = new Lutador("Iron Fist", "USA", 23, 20, 1, 5, 1.83f, 82.2f);
                
        Luta UEC01 = new Luta();
        UEC01.marcarLuta(l[1], l[4]);
        UEC01.lutar();
        l[1].status();
        l[4].status();
    }
    
}
