/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetolivro;

/**
 *
 * @author Gabriel
 */
public class ProjetoLivro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pessoa[] p = new Pessoa[2];
        Livro[] l = new Livro[3];
        
        p[0] = new Pessoa("Pedro", 22, "M");
        p[1] = new Pessoa("Maria", 25, "F");
        
        l[0] = new Livro("Kenobi", "John Jackson Miller", 525, p[0]);
        l[1] = new Livro("A Arma de um Jedi", "Jason Fry", 198, p[1]);
        l[2] = new Livro("Thrawn", "Timothy Zahn", 437, p[0]);
        
        l[0].abrir();
        l[0].folhear(200);
        System.out.println("Detalhes do livro:\n" + l[0].detalhes());
    }
    
}
