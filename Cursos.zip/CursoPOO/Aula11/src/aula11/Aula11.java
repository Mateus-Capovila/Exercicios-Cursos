/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula11;

/**
 *
 * @author Gabriel
 */
public class Aula11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Visitante v1 = new Visitante();
        v1.setNome("Ezra");
        v1.setIdade(18);
        v1.setSexo("M");
        
        Aluno a1 = new Aluno();
        a1.setNome("Harry");
        a1.setIdade(15);
        a1.setSexo("M");
        a1.setMatr(123);
        a1.setCurso("Ciências");
        a1.pagarMensalidade();
        
        Bolsista b1 = new Bolsista();
        b1.setNome("Peter");
        b1.setIdade(15);
        b1.setSexo("M");
        b1.setMatr(1234);
        b1.setCurso("Ciências");
        b1.setBolsa(80f);
        b1.pagarMensalidade();
        
        System.out.println(a1.toString());
    }
    
}
