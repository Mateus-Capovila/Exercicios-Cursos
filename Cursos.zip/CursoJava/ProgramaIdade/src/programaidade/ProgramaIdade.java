/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programaidade;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class ProgramaIdade {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digite o ano em que você nasceu");
        int nasc = teclado.nextInt();
        int i = 2020 - nasc;
        
        System.out.println("Sua idade é " + i);
        
        if(i<18){
            System.out.println("Você é menor de idade");
        }
        else{
            System.out.println("Você é maior de idade");
        }
        
        if(i<16){
            System.out.println("Você não pode votar");
        }
        else if((i>=16 && i<18) || i>=60){
            System.out.println("Seu voto é opcional");
        }
        else{
            System.out.println("Seu voto é obrigatório");
        }
    }
    
}
