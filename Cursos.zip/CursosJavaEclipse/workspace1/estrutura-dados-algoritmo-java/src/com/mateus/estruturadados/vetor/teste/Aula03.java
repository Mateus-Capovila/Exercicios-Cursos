package com.mateus.estruturadados.vetor.teste;

import com.mateus.estruturadados.vetor.Vetor;

public class Aula03 {

	public static void main(String[] args) {
		Vetor vetor = new Vetor(2);
		
		vetor.adiciona("1");
		vetor.adiciona("2");
		vetor.adiciona("3");
		
	}

}
