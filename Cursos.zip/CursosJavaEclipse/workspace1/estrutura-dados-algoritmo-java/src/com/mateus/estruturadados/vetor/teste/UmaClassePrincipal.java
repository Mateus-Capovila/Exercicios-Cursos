package com.mateus.estruturadados.vetor.teste;

import java.util.ArrayList;

public class UmaClassePrincipal {

	public static void main(String[] args) {
		
		Oi ee = new Oi("Mateus", "tipo 1", "irguwegue");
		Oi paste = new Oi("Pastante", "tipo 2", "erwtqrrtthn");
		
		ArrayList<Oi> ois = new ArrayList<Oi>();
		
		ois.add(new Oi ("Natasha", "qwrt", "ett"));
		ois.add(new Oi ("Clint", "rgg", "eee"));
		ois.add(new Oi ("Tony", "jrtj", "plplpl"));
		ois.add(new Oi ("Steve", "errfg", "myrurtj"));
		ois.add(ee);
		ois.add(2, new Oi("Thor", "regg", "weerwe"));
		
		System.out.println(ois);
		System.out.println(ois.size());
		System.out.println(ois.get(2));
		System.out.println(ois.contains(paste));
		System.out.println(ois.indexOf(ee));
		
		ois.remove(0);
		System.out.println(ois);
		ois.remove(ee);
		System.out.println(ois);
		ois.clear();
		System.out.println(ois);

	}

	
		
}
