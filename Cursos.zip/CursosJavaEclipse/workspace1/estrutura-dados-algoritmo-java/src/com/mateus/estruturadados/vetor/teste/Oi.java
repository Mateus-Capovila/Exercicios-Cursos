package com.mateus.estruturadados.vetor.teste;

public class Oi {

	String nome = new String();
	String tipo = new String();
	String qualquerCoisa = new String();
	
	public Oi(String nome, String tipo, String qualquerCoisa) {
		super();
		this.nome = nome;
		this.tipo = tipo;
		this.qualquerCoisa = qualquerCoisa;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getQualquerCoisa() {
		return qualquerCoisa;
	}

	public void setQualquerCoisa(String qualquerCoisa) {
		this.qualquerCoisa = qualquerCoisa;
	}

	@Override
	public String toString() {
		return "Oi [nome=" + nome + ", tipo=" + tipo + ", qualquerCoisa=" + qualquerCoisa + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		result = prime * result + ((qualquerCoisa == null) ? 0 : qualquerCoisa.hashCode());
		result = prime * result + ((tipo == null) ? 0 : tipo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Oi other = (Oi) obj;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (qualquerCoisa == null) {
			if (other.qualquerCoisa != null)
				return false;
		} else if (!qualquerCoisa.equals(other.qualquerCoisa))
			return false;
		if (tipo == null) {
			if (other.tipo != null)
				return false;
		} else if (!tipo.equals(other.tipo))
			return false;
		return true;
	}
	
	

	
	

}
