public class MinhaExcessao extends Exception{ 
	
	public MinhaExcessao(String msg) {
		super(msg);
	}

}
