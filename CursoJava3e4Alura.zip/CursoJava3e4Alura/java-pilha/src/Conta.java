
public class Conta {
	
	void deposita() throws MinhaExcessao {
		
	}

}
