
public class TesteFuncionario {

	public static void main(String[] args) {
		
		Administrador lando = new Administrador();
		lando.setNome("Lando Calrissian");
		lando.setCpf("8498484111");
		lando.setSalario(4000.00);

		System.out.println(lando.getNome());
		System.out.println(lando.getBonificacao());
		
	}

}
